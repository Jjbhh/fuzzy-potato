package com.stark.roomgate;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.GameMode;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class RoomGate extends JavaPlugin implements Listener {

    private static final String WAND_NAME = ChatColor.GOLD + "RoomGate Wand";
    private static final Material GATE_MATERIAL = Material.GRAY_STAINED_GLASS;

    /** Number of players needed inside the room to close the gate. */
    private int requiredPlayers = 2;

    /** Extra blocks of margin around the room area, so edges count as inside. */
    private static double edgeTolerance = 1.0;

    /** Max players allowed inside; extras are teleported out. */
    private int maxPlayers = 2;

    /** Kill a player who disconnects while a match is running (gate closed). */
    private boolean killOnQuit = true;
    private String quitKillMessage = "&e%player% left the game during a match and was killed.";
    private String roomFullMessage = "&cThis room is full!";

    // Sound settings (loaded from config.yml)
    private boolean soundsEnabled = true;
    private Sound closeSound;
    private Sound openSound;
    private float soundVolume = 2.0f;
    private float closePitch = 1.0f;
    private float openPitch = 1.0f;

    private final Map<String, Room> rooms = new LinkedHashMap<>();
    private final Map<UUID, Location[]> selections = new HashMap<>();

    private File roomsFile;
    private NamespacedKey wandKey;

    // ------------------------------------------------------------------ data

    private static class Region {
        final String world;
        final int minX, minY, minZ, maxX, maxY, maxZ;
        /** If true, the XZ shape is a circle/ellipse inscribed in the box instead of a rectangle. */
        boolean ellipse = false;

        Region(Location a, Location b) {
            this.world = a.getWorld().getName();
            this.minX = Math.min(a.getBlockX(), b.getBlockX());
            this.minY = Math.min(a.getBlockY(), b.getBlockY());
            this.minZ = Math.min(a.getBlockZ(), b.getBlockZ());
            this.maxX = Math.max(a.getBlockX(), b.getBlockX());
            this.maxY = Math.max(a.getBlockY(), b.getBlockY());
            this.maxZ = Math.max(a.getBlockZ(), b.getBlockZ());
        }

        Region(ConfigurationSection s) {
            this.world = s.getString("world");
            this.minX = s.getInt("minX");
            this.minY = s.getInt("minY");
            this.minZ = s.getInt("minZ");
            this.maxX = s.getInt("maxX");
            this.maxY = s.getInt("maxY");
            this.maxZ = s.getInt("maxZ");
            this.ellipse = s.getBoolean("ellipse", false);
        }

        void save(ConfigurationSection s) {
            s.set("world", world);
            s.set("minX", minX);
            s.set("minY", minY);
            s.set("minZ", minZ);
            s.set("maxX", maxX);
            s.set("maxY", maxY);
            s.set("maxZ", maxZ);
            s.set("ellipse", ellipse);
        }

        boolean contains(Location l) {
            if (l.getWorld() == null || !l.getWorld().getName().equals(world)) return false;

            int y = l.getBlockY();
            if (y < minY || y > maxY) return false;

            // Extra margin so standing on the very edge still counts as inside.
            double t = edgeTolerance;
            double px = l.getX(), pz = l.getZ();
            if (px < minX - t || px > maxX + 1 + t || pz < minZ - t || pz > maxZ + 1 + t) return false;
            if (!ellipse) return true;

            // Circle/ellipse inscribed in the XZ bounding box (plus the margin).
            double cx = (minX + maxX + 1) / 2.0;
            double cz = (minZ + maxZ + 1) / 2.0;
            double rx = (maxX - minX + 1) / 2.0 + t;
            double rz = (maxZ - minZ + 1) / 2.0 + t;
            double dx = (px - cx) / rx;
            double dz = (pz - cz) / rz;
            return dx * dx + dz * dz <= 1.0;
        }

        void fill(Material m) {
            World w = Bukkit.getWorld(world);
            if (w == null) return;
            for (int x = minX; x <= maxX; x++) {
                for (int y = minY; y <= maxY; y++) {
                    for (int z = minZ; z <= maxZ; z++) {
                        w.getBlockAt(x, y, z).setType(m, false);
                    }
                }
            }
        }
    }

    private static class Room {
        final String name;
        Region area;
        Region gate;
        boolean closed = false;

        /** Players currently inside, in the order they entered. */
        final LinkedHashSet<UUID> inside = new LinkedHashSet<>();
        /** Last known position of each player while outside the room. */
        final Map<UUID, Location> lastOutside = new HashMap<>();

        Room(String name) {
            this.name = name;
        }
    }

    // ------------------------------------------------------------- lifecycle

    @Override
    public void onEnable() {
        saveDefaultConfig();
        wandKey = new NamespacedKey(this, "wand");
        loadSettings();

        roomsFile = new File(getDataFolder(), "rooms.yml");
        // First run: install the default rooms bundled inside the jar.
        if (!roomsFile.exists()) saveResource("rooms.yml", false);
        loadRooms();

        Bukkit.getPluginManager().registerEvents(this, this);

        // Check every 2 ticks (0.1s) so the gate reacts almost instantly.
        Bukkit.getScheduler().runTaskTimer(this, this::tickRooms, 20L, 2L);
    }

    @Override
    public void onDisable() {
        // Leave every gate open when the plugin stops.
        for (Room r : rooms.values()) {
            if (r.gate != null && r.closed) r.gate.fill(Material.AIR);
        }
    }

    // ------------------------------------------------------------- main loop

    private void tickRooms() {
        for (Room room : rooms.values()) {
            if (room.area == null || room.gate == null) continue;

            // 1) Who is inside right now?
            Set<UUID> nowInside = new LinkedHashSet<>();
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.isDead() || p.getGameMode() == GameMode.SPECTATOR) continue;
                if (room.area.contains(p.getLocation())) {
                    nowInside.add(p.getUniqueId());
                } else {
                    room.lastOutside.put(p.getUniqueId(), p.getLocation().clone());
                }
            }

            // 2) Keep entry order: old players stay first, newcomers are appended.
            room.inside.retainAll(nowInside);
            room.inside.addAll(nowInside);

            // 3) Too many players? Eject the ones who entered last.
            if (room.inside.size() > maxPlayers) {
                Iterator<UUID> it = room.inside.iterator();
                int i = 0;
                while (it.hasNext()) {
                    UUID id = it.next();
                    if (++i > maxPlayers) {
                        it.remove();
                        ejectPlayer(room, id);
                    }
                }
            }

            // 4) Open or close the gate.
            boolean shouldClose = room.inside.size() >= requiredPlayers;

            if (shouldClose && !room.closed) {
                room.gate.fill(GATE_MATERIAL);
                room.closed = true;
                playSound(room.gate, closeSound, closePitch);
            } else if (!shouldClose && room.closed) {
                room.gate.fill(Material.AIR);
                room.closed = false;
                playSound(room.gate, openSound, openPitch);
            }
        }
    }

    private void ejectPlayer(Room room, UUID id) {
        Player p = Bukkit.getPlayer(id);
        if (p == null) return;

        Location dest = room.lastOutside.get(id);
        if (dest == null || dest.getWorld() == null) dest = p.getWorld().getSpawnLocation();

        p.setVelocity(new org.bukkit.util.Vector(0, 0, 0));
        p.teleport(dest);
        p.sendMessage(ChatColor.translateAlternateColorCodes('&', roomFullMessage));
    }

    // ---------------------------------------------------------------- sounds

    private void loadSettings() {
        reloadConfig();
        requiredPlayers = Math.max(2, getConfig().getInt("required-players", 2));
        maxPlayers = Math.max(requiredPlayers, getConfig().getInt("max-players", 2));
        edgeTolerance = Math.max(0.0, getConfig().getDouble("edge-tolerance", 1.0));
        killOnQuit = getConfig().getBoolean("kill-on-quit", true);
        quitKillMessage = getConfig().getString("messages.quit-kill", "&e%player% left the game during a match and was killed.");
        roomFullMessage = getConfig().getString("messages.room-full", "&cThis room is full!");

        soundsEnabled = getConfig().getBoolean("sounds.enabled", true);
        soundVolume = (float) getConfig().getDouble("sounds.volume", 2.0);
        closeSound = findSound(getConfig().getString("sounds.close.sound", "block.iron_door.close"));
        closePitch = (float) getConfig().getDouble("sounds.close.pitch", 0.8);
        openSound = findSound(getConfig().getString("sounds.open.sound", "block.iron_door.open"));
        openPitch = (float) getConfig().getDouble("sounds.open.pitch", 1.0);
    }

    private Sound findSound(String key) {
        NamespacedKey nk = NamespacedKey.fromString(key == null ? "" : key.toLowerCase());
        Sound s = nk == null ? null : Registry.SOUNDS.get(nk);
        if (s == null) getLogger().warning("Unknown sound in config.yml: " + key);
        return s;
    }

    private void playSound(Region gate, Sound sound, float pitch) {
        if (!soundsEnabled || sound == null) return;
        World w = Bukkit.getWorld(gate.world);
        if (w == null) return;
        Location center = new Location(w,
                (gate.minX + gate.maxX + 1) / 2.0,
                (gate.minY + gate.maxY + 1) / 2.0,
                (gate.minZ + gate.maxZ + 1) / 2.0);
        w.playSound(center, sound, soundVolume, pitch);
    }

    // ---------------------------------------------------------------- wand

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getClickedBlock() == null) return;

        Player p = e.getPlayer();
        if (!p.hasPermission("roomgate.admin")) return;

        ItemStack item = p.getInventory().getItemInMainHand();
        if (item.getType() != Material.BLAZE_ROD || !item.hasItemMeta()) return;
        ItemMeta meta = item.getItemMeta();
        if (meta == null || !meta.getPersistentDataContainer().has(wandKey, PersistentDataType.BYTE)) return;

        e.setCancelled(true);

        Location[] sel = selections.computeIfAbsent(p.getUniqueId(), k -> new Location[2]);
        Location loc = e.getClickedBlock().getLocation();

        if (e.getAction() == Action.LEFT_CLICK_BLOCK) {
            sel[0] = loc;
            p.sendMessage(ChatColor.GREEN + "Position 1 set: " + fmt(loc));
        } else if (e.getAction() == Action.RIGHT_CLICK_BLOCK) {
            sel[1] = loc;
            p.sendMessage(ChatColor.GREEN + "Position 2 set: " + fmt(loc));
        }
    }

    // ------------------------------------------------------------ quit = death

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        if (!killOnQuit) return;

        Player p = e.getPlayer();
        if (p.isDead() || p.getGameMode() == GameMode.SPECTATOR) return;

        for (Room room : rooms.values()) {
            // Only while the match is running: gate closed and the player is inside.
            if (room.area == null || room.gate == null || !room.closed) continue;
            if (!room.area.contains(p.getLocation())) continue;

            String msg = ChatColor.translateAlternateColorCodes('&',
                    quitKillMessage.replace("%player%", p.getName()));
            for (UUID id : room.inside) {
                Player other = Bukkit.getPlayer(id);
                if (other != null && !other.equals(p)) other.sendMessage(msg);
            }

            p.setHealth(0.0);
            break;
        }
    }

    private String fmt(Location l) {
        return l.getBlockX() + ", " + l.getBlockY() + ", " + l.getBlockZ();
    }

    // ------------------------------------------------------------ commands

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Players only.");
            return true;
        }

        if (args.length == 0) {
            help(p);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "wand" -> {
                ItemStack wand = new ItemStack(Material.BLAZE_ROD);
                ItemMeta meta = wand.getItemMeta();
                meta.setDisplayName(WAND_NAME);
                meta.getPersistentDataContainer().set(wandKey, PersistentDataType.BYTE, (byte) 1);
                meta.setLore(List.of(
                        ChatColor.GRAY + "Left click: position 1",
                        ChatColor.GRAY + "Right click: position 2"));
                wand.setItemMeta(meta);
                p.getInventory().addItem(wand);
                p.sendMessage(ChatColor.GREEN + "You received the wand.");
            }
            case "create" -> {
                if (args.length < 2) {
                    p.sendMessage(ChatColor.RED + "/room create <name> [circle]");
                    return true;
                }
                Region r = selectionRegion(p);
                if (r == null) return true;

                boolean round = args.length >= 3
                        && (args[2].equalsIgnoreCase("circle") || args[2].equalsIgnoreCase("round"));
                r.ellipse = round;

                String name = args[1].toLowerCase();
                Room room = rooms.computeIfAbsent(name, Room::new);
                room.area = r;
                saveRooms();
                p.sendMessage(ChatColor.GREEN + "Room '" + name + "' area saved (" + (round ? "circle" : "box") + ")."
                        + (room.gate == null ? ChatColor.YELLOW + " Now select the gate and run /room setgate " + name : ""));
            }
            case "setgate" -> {
                if (args.length < 2) {
                    p.sendMessage(ChatColor.RED + "/room setgate <name>");
                    return true;
                }
                Room room = rooms.get(args[1].toLowerCase());
                if (room == null) {
                    p.sendMessage(ChatColor.RED + "Room not found. Create it first with /room create <name>.");
                    return true;
                }
                Region r = selectionRegion(p);
                if (r == null) return true;

                // Reset the old gate first if it was closed.
                if (room.gate != null && room.closed) room.gate.fill(Material.AIR);
                room.closed = false;
                room.gate = r;
                saveRooms();
                p.sendMessage(ChatColor.GREEN + "Gate saved for room '" + room.name + "'.");
            }
            case "delete" -> {
                if (args.length < 2) {
                    p.sendMessage(ChatColor.RED + "/room delete <name>");
                    return true;
                }
                Room room = rooms.remove(args[1].toLowerCase());
                if (room == null) {
                    p.sendMessage(ChatColor.RED + "Room not found.");
                    return true;
                }
                if (room.gate != null && room.closed) room.gate.fill(Material.AIR);
                saveRooms();
                p.sendMessage(ChatColor.GREEN + "Room deleted.");
            }
            case "list" -> {
                if (rooms.isEmpty()) {
                    p.sendMessage(ChatColor.YELLOW + "No rooms.");
                    return true;
                }
                for (Room r : rooms.values()) {
                    p.sendMessage(ChatColor.GOLD + r.name + ChatColor.GRAY
                            + " | area: " + (r.area != null ? "✔" : "✘")
                            + " | gate: " + (r.gate != null ? "✔" : "✘")
                            + " | " + (r.closed ? "closed" : "open"));
                }
            }
            case "reload" -> {
                loadSettings();
                p.sendMessage(ChatColor.GREEN + "Config reloaded.");
            }
            default -> help(p);
        }
        return true;
    }

    private void help(Player p) {
        p.sendMessage(ChatColor.GOLD + "---- RoomGate ----");
        p.sendMessage(ChatColor.YELLOW + "/room wand" + ChatColor.GRAY + " - get the selection wand");
        p.sendMessage(ChatColor.YELLOW + "/room create <name> [circle]" + ChatColor.GRAY + " - save selection as the room area (circle = round room)");
        p.sendMessage(ChatColor.YELLOW + "/room setgate <name>" + ChatColor.GRAY + " - save selection as the gate");
        p.sendMessage(ChatColor.YELLOW + "/room delete <name>");
        p.sendMessage(ChatColor.YELLOW + "/room list");
        p.sendMessage(ChatColor.YELLOW + "/room reload");
    }

    private Region selectionRegion(Player p) {
        Location[] sel = selections.get(p.getUniqueId());
        if (sel == null || sel[0] == null || sel[1] == null) {
            p.sendMessage(ChatColor.RED + "Select two positions with the wand first (/room wand).");
            return null;
        }
        if (!Objects.equals(sel[0].getWorld(), sel[1].getWorld())) {
            p.sendMessage(ChatColor.RED + "Both positions must be in the same world.");
            return null;
        }
        return new Region(sel[0], sel[1]);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (args.length == 1) {
            return filter(List.of("wand", "create", "setgate", "delete", "list", "reload"), args[0]);
        }
        if (args.length == 2 && List.of("setgate", "delete").contains(args[0].toLowerCase())) {
            return filter(new ArrayList<>(rooms.keySet()), args[1]);
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("create")) {
            return filter(List.of("circle"), args[2]);
        }
        return Collections.emptyList();
    }

    private List<String> filter(List<String> list, String prefix) {
        List<String> out = new ArrayList<>();
        for (String s : list) if (s.startsWith(prefix.toLowerCase())) out.add(s);
        return out;
    }

    // ----------------------------------------------------------- persistence

    private void loadRooms() {
        rooms.clear();
        if (!roomsFile.exists()) return;

        YamlConfiguration yml = YamlConfiguration.loadConfiguration(roomsFile);
        ConfigurationSection root = yml.getConfigurationSection("rooms");
        if (root == null) return;

        for (String name : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(name);
            if (s == null) continue;
            Room room = new Room(name);
            if (s.isConfigurationSection("area")) room.area = new Region(s.getConfigurationSection("area"));
            if (s.isConfigurationSection("gate")) {
                room.gate = new Region(s.getConfigurationSection("gate"));
                // Start with the gate open after a restart.
                room.gate.fill(Material.AIR);
            }
            rooms.put(name, room);
        }
    }

    private void saveRooms() {
        YamlConfiguration yml = new YamlConfiguration();
        for (Room r : rooms.values()) {
            String base = "rooms." + r.name;
            if (r.area != null) r.area.save(yml.createSection(base + ".area"));
            if (r.gate != null) r.gate.save(yml.createSection(base + ".gate"));
        }
        try {
            getDataFolder().mkdirs();
            yml.save(roomsFile);
        } catch (IOException ex) {
            getLogger().severe("Could not save rooms.yml: " + ex.getMessage());
        }
    }
}
